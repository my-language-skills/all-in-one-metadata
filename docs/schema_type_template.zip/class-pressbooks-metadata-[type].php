<?php
/**
 * The class for the [schematype] type including operations and metaboxes
 *
 * @link       https://github.com/Books4Languages/pressbooks-metadata
 * @since      0.x
 *
 * @package    Pressbooks_Metadata
 * @subpackage Pressbooks_Metadata/admin/schemaTypes
 * @author     Christos Amyrotos <christosv2@hotmail.com>
 * @author     Vasilis Georgoudis <vasilios.georgoudis@gmail.com>
 */

class Pressbooks_Metadata_[schematype] {

   /**
    * The type level where these metaboxes and their schema operations will go
    *
    * @since    0.x
    * @access   private
    */
   private $type_level;

   public function __construct($type_level_input) {
      $this->type_level = $type_level_input;
      $this->pmdt_add_metabox($this->type_level);
   }
   /**
    * The function which produces the metaboxes for the [schematype] type
    * @param string Accepting a string so we can distinguish on witch place each metabox is created
    * The value passed here is also used when calling the metadata functions in the header and the footer.
    * @since 0.8.1
    */
   private function pmdt_add_metabox($meta_position){
      //----------- metabox ----------- //
      x_add_metadata_group(  '[schematype]', $meta_position, array(
         'label'       => '[schematype] Type Properties',
         'priority'        => 'high',
     ) );
     //----------- metafields ----------- //
     // [schemaprop]
     x_add_metadata_field(  'pb_[schemaprop]_'.$meta_position, $meta_position, array(
        'group'       =>     '[schematype]',
        'label'       =>     '[schemaprop]',
     ) );
  }

     /* FUNCTIONS FOR THIS TYPE START HERE */

  /**
   * Returns type level.
   *
   * @since    0.x
   * @access   public
   */
  public function pmdt_get_type_level(){
        return $this->type_level;
     }

  /**
   * A function needed for the array of metadata that comes from each post or chapter
   * It automatically returns the first item in the array.
   * @since 0.8.1
   *
   */
  private function pmdt_get_first($my_array){
     return $my_array[0];
  }
  /**
   * A function that creates the metadata for the [schematype] type.
   * @since 0.8.1
   *
   */
  public function pmdt_get_metatags() {
     //Distinguishing if we are working on a post --- chapter level or on the main site level
     //The type_level variable is the string we used to create the metabox

     if ( $this->type_level == 'chapter' ) { //loading the appropriate metadata depending on the type level
        $metadata = get_post_meta( get_the_ID() );
     } else {
        $metadata = \Pressbooks\Book::getBookInformation();
     }

     // array of the items needed to become microtags
     $book_data = array(

        '[schemaprop]' => '[schema-meta-vlaue]',
        '[schemaprop]' => '[schema-meta-value]' 
     );

     $html = "<!-- Microtags --> \n";

     //This code is needed for the [schemtaype] type on chapter 
	 level because by default the chapter is a website
	       $html .= ( $this->type_level == 'chapter' ? '<div itemscope itemtype="http://schema.org/[schematype]">' : '' );

	       foreach ( $book_data as $itemprop => $content ) {
	          if ( isset( $metadata[ $content . '_' . $this->type_level ] ) ) {

	             if ( $this->type_level == 'chapter' ) { //we are using the get_first function to get the value from the returned array
	                $value = $this->pmdt_get_first( $metadata[ $content . '_' . $this->type_level ] );
	             } else {
	                $value = $metadata[ $content . '_' . $this->type_level ];
	             }

	             $html .= "<meta itemprop = '" . $itemprop . "' content = '" . $value . "'>\n";
	          }
	       }
	       $html .= ( $this->type_level == 'chapter' ? '</div>' : '' );
	       return $html;
	    }
	 }
	 
<?php

namespace schemaTypes;

/**
 * The class for the [parent-type-name] type including just the properties, this type will inject properties on its child types
 *
 * @link       https://github.com/Books4Languages/pressbooks-metadata
 * @since      0.x
 *
 * @package    Pressbooks_Metadata
 * @subpackage Pressbooks_Metadata/admin/schemaTypes
 * @author     Christos Amyrotos <christosv2@hotmail.com>
 */

class Pressbooks_Metadata_[parent-type-name] {

	const type_name = array('[parent-type-name] Properties','[parent-type-name]_properties');

	const type_properties = array(
		//Here you enter the properties for the parent type, the boolean variable makes this property mandatory to be used by the user
		//[property-name-title] is the value that is displayed as the field title
		//If you want to make a drop down list use the fourth parrameter in the =>array('','','',array('value'=>'field_name','value'=>'field_name'))
		//If you want to generate a number field use the fourth parameter in the =>array('','','','number')
		//'illustrator' => array(true,'Illustrator','This is the Description of Illustrator') -> example please remove
		'[property-name]' => array(true,'[property-name-title]','[property-description]'),
	);
}
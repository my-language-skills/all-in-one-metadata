<?php

//Remember to include the correct namespace of the folder
//For example CreativeWork types go in folder admin/schemaTypes/CreativeWorks, this folder has namespace schemaTypes\cw
//If you forget a folder namespace find it from a file in the same folder or from the composer.json

namespace schemaTypes\[namespace];
use schemaTypes;
use schemaTypes\Pressbooks_Metadata_Type;

/**
 * The class for the [schema-type-name] type including operations and metaboxes
 *
 * @link       https://github.com/Books4Languages/pressbooks-metadata
 * @since      0.8.1
 *
 * @package    Pressbooks_Metadata
 * @subpackage Pressbooks_Metadata/admin/schemaTypes
 * @author     Christos Amyrotos <christosv2@hotmail.com>
 * @author     Vasilis Georgoudis <vasilios.georgoudis@gmail.com>
 */

class Pressbooks_Metadata_[schema-type-name] extends Pressbooks_Metadata_Type {

	/**
	 * The variable that holds the values for the settings for this schema type
	 *
	 * @since    0.x
	 * @access   public
	 */
	static $type_setting = array('[schema-type-name]_type' => array('[schema-type-name] Type','http://schema.org/[schema-type-name]'));
	//static $type_setting = array('book_type' => array('Book Type','http://schema.org/Book'));->example please remove

	/**
	 * The variable that holds the parents for the type
	 *
	 * @since    0.x
	 * @access   public
	 */
	static $type_parents = array(
		'schemaTypes\Pressbooks_Metadata_Thing',
		//Include all parent namespaces that are related with this type
		//Thing parent goes to all types
	);

	/**
	 * The variable that holds the properties of this schema type
	 *
	 * @since    0.x
	 * @access   public
	 */
	static $type_properties = array(
		//Here you enter the properties for the schema type, the boolean variable makes this property mandatory to be used by the user
		//[property-name-title] is the value that is displayed as the field title
		//If you want to make a drop down list use the fourth parrameter in the =>array('','','',array('value'=>'field_name','value'=>'field_name'))
		//If you want to generate a number field use the fourth parameter in the =>array('','','','number')
		//'illustrator' => array(true,'Illustrator','This is the Description of Illustrator') -> example please remove
		'[property-name]' => array(true,'[property-name-title]','[property-description]'),
	);

	public function __construct($type_level_input) {
		parent::__construct($type_level_input);
		$this->type_fields = $this->get_all_properties();
		$this->class_name = __CLASS__ .'_'. $this->type_level;
		$this->pmdt_populate_names(self::$type_setting);
		$this->pmdt_add_metabox($this->type_level);
	}

	/**
	 * Function used for combining the current types properties with its parents fields
	 *
	 * @since    0.x
	 * @access   public
	 */
	public function get_all_properties() {
		$properties = self::$type_properties;
		foreach(self::$type_parents as $parentType){
			$properties = array_merge($properties,$parentType::type_properties);
		}
		return $properties;
	}

	/**
	 * Function used for comparing the instances of the schema types
	 *
	 * @since    0.x
	 * @access   public
	 */
	public function __toString() {
		return $this->class_name;
	}
}
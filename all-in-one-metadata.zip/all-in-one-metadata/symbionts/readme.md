#ABOUT SYMBIONTS

Symbionts are 3rd party open source vendors that may or may not be licensed
under the GPLv3.

These additional libraries have their own licensing requirements and, as such,
should not be directly modified by My Language Skills developers.

##Symbionts used in plugin

### Custom Metadata

Custom Metadata plugin allows creation of custom metaboxes for any post types, with interactive fields and other benefits. All In One Metadata utilizes it to create metaboxes for schema properties.

The Custom Metadata plugin files are allocated in [custom-metadata](custom-metadata) folder.